import React from 'react';

function SideBarFilter() {
  return (
    <div>
      <div className="container-wide bg-white pad-30">
        <div className="pure-g justify-between">
          <div className="pure-u-1 pure-u-md-1-4">
            <h2>Filter</h2>
            All filters will be here
          </div>
        </div>
      </div>
    </div>
  );
}

export default SideBarFilter;
